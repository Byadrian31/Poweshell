#!/bin/bash

# Verifica si se proporciona un argumento
if [ $# -ne 1 ]; then
    echo "Uso: $0 <N>"
    exit 1
fi

# Obtiene el valor de N del argumento
N=$1

# Ciclo para imprimir las filas del triángulo
for ((i=1; i<=N; i++)); do
    # Ciclo para imprimir los números en cada fila
    for ((j=1; j<=i; j++)); do
        # Imprime el número de la fila en cada iteración
        echo -n "$i "
    done
    # Salto de línea para pasar a la siguiente fila
    echo
done
