#!/bin/bash
while true; do
  clear
  echo "Menu de opciones:"
  echo "1. Sumar"
  echo "2. Restar"
  echo "3. Multiplicar"
  echo "4. Dividir"
  echo "5. Salir"
  read -p "Selecciona un opcion (1-5): " OPCION

  case "$OPCION" in
      1)
	read -p "Dime primer numero: " num1
 	read -p "Dime segundo numero: " num2
	let total=num1+num2
	echo $total
	sleep 2

	;;
  2)
        read -p "Dime primer numero: " num1
        read -p "Dime segundo numero: " num2
        let total=num1-num2
        echo $total
        sleep 2
        ;;


  3)
        read -p "Dime primer numero: " num1
        read -p "Dime segundo numero: " num2
        let total=num1*num2
        echo $total
        sleep 2
        ;;


  4)
	read -p "Dime primer numero: " num1
 	read -p "Dime segundo numero: " num2

	if [ "$num1" -gt "$num2" ]; then
	        let total=num1/num2
        	echo $total
        	sleep 2
	else
    		echo "$num2 es mayor que $num1"
		sleep 2
	fi
	;;
  5)
	echo "Saliendo del programa..."
	exit 0
	;;

  *)
	echo "Opcion invalida. Selecciona entre 1-5"
	;;
  esac
done
