#!/bin/bash
# Verificar si se proporcionan argumentos
for arg in "$@"; do
   for ((i=1 ; i<=$arg; i++)); do
        echo -n "*"
   done
    echo
done
