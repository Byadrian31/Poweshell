#!/bin/bash

echo "Dime tu nombre:"
read nombre

cat /etc/passwd | grep $nombre
