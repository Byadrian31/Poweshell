#!/bin/bash

direc="seguridad"

if [ ! -d $direc ]; then
  mkdir $direc
  echo "Directorio creado"
fi

cp * $direc
echo "Contenido $direc :"
ls $direc
