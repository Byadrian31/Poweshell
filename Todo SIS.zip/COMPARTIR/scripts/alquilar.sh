#!/bin/bash
# Mostrar vehiculos que se pueden alquilar
echo "Los vehiculos disponibles son: "
echo "Coche, Furgoneta, Bicicleta"

read -p "¿Que vehiculo quieres? " ve

if [ "$ve" -eq "Coche"  ]; then
	echo "20€/km"

elif [ "$ve" -eq "Furgoneta"  ]; then
	echo "10€/km"

elif [ "$ve" -eq "Bicicleta"  ]; then
	echo "5€/km"

else
	echo "Introduce un vehiculo valido"
fi

