#!/bin/bash
#Obtener el numero mayor
read -p "Dime el primer numero: " num1
read -p "Dime el segundo numero: " num2

if [ "$num1" -gt "$num2" ]; then
    echo "$num1 es mayor que $num2"
    echo "$num2 es menor que $num1"
elif [ "$num2" -gt "$num1" ]; then
    echo "$num2 es mayor que $num1"
    echo "$num1 es menor que $num2"
else
    echo "Ambos números son iguales"
fi
