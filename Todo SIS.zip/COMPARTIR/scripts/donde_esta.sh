#!/bin/bash
#Para cada elemento del $PATH
for i in `echo $PATH | tr ":" " "`
do
	if [ -x $i/$1  ]; then
	 echo localizado en $i
	 man -f $1
	fi
done
