#!/bin/bash
# Verificar si se proporcionan argumentos
if [ $# -eq 0 ]; then
    echo "Error: No se han proporcionado argumentos."
    exit 1
fi

# Iterar sobre cada argumento
for arg in "$@"; do
    # Verificar si el argumento está dentro del rango 1-75
    if [ "$arg" -lt 1 ] || [ "$arg" -gt 75 ]; then
        echo "Error: El número '$arg' está fuera del rango permitido (1-75)."
        exit 1
    fi

   for ((i=1; i<=$arg; i++)); do
        echo -n "*"
    done
    echo
done
