#!/bin/bash

while true; do
  clear
  echo "Menu de opciones:"
  echo "1. Sumar"
  echo "2. Restar"
  echo "3. Multiplicar"
  echo "4. Dividir"
  echo "5. Salir"
  read -p "Selecciona una opción (1-5): " OPCION

  case "$OPCION" in
    1|2|3|4)
      # Solicitar primer número y realizar validación
      while true; do
        read -p "Dime el primer número: " num1
        if [[ "$num1" =~ ^[0-9]+$ ]]; then
          break
        else
          echo "Error: Por favor, introduce un número válido."
        fi
      done

      # Solicitar segundo número y realizar validación
      while true; do
        read -p "Dime el segundo número: " num2
        if [[ "$num2" =~ ^[0-9]+$ ]]; then
          break
        else
          echo "Error: Por favor, introduce un número válido."
        fi
      done

      # Realizar la operación correspondiente según la opción seleccionada
      case "$OPCION" in
        1)
		echo "SUMA: " 
		let total=num1+num2 ;;
        2)
		echo "Resta: "
		let total=num1-num2 ;;
        3)
		echo "Multiplicar: "
		let total=num1*num2 ;;
        4)
	  echo "Division:"
          if [ "$num2" -eq 0 ]; then
            echo "Error: No se puede dividir por cero."
            sleep 2
            continue
          fi
          let total=num1/num2 ;;
      esac

      echo "El resultado es: $total"
      sleep 2
      ;;
    5)
      echo "Saliendo del programa..."
      exit 0
      ;;
    *)
      echo "Opción inválida. Por favor, selecciona una opción entre 1-5."
      sleep 2
      ;;
  esac
done
