#!/bin/bash
#Media de los parametros

c=0
total=0
for num in "$@"; do
	let total=total+$num
	let c++
done
let media=total/c
echo "La media es: $media"
