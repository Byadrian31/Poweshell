#!/bin/bash
#Mostrar los archivos pasados por parametros

clear
for file in "$@"; do
   if [ ! -z "$file" ] ; then
	echo
        echo "Contenido de $file: "
        cat $file
	echo
	echo "<-------------------------------------------------------------->"
   else
        echo "No se encuentra el archivo $file"
   fi
done
