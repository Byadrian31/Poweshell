#!/bin/bash
# Guarda ficheros

clear
DATA=`date +%y-%m-%d`
echo
read -p "Introduce PATH absoluto de los ficheros a guardar: " DIRORI
read -p "Introduce PATH absoluto del directorio destino: " DIRDEST
read -p "Se va a comrpimir en un tar los ficheros, indica el nombre: " NOM

if [ -d $DIRORI ]
then
	if [ ! -d $DIRDEST ]
	then
		echo "Creando directorio"
		mkdir $DIRDEST
	fi
	tar cvf $DIRDEST/$NOM-$DATA.tar $DIRORI
	echo "Se han guardado los ficheros"
else
	echo "No se han podido guardar los ficheros"
fi
echo
