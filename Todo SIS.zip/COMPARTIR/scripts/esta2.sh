#!/bin/bash
# Comprobar si están los usuarios pasados por parámetros
# Comprobando si el usuario está conectado

for usu in "$@"; do
    if who | grep -wq "$usu"; then
        echo "$usu está conectado al sistema en estos momentos."
    else
        echo "$usu no está conectado al sistema en estos momentos."
    fi
done
