#!/bin/bash
# Mi primer script
clear
echo "Hola mundo :)"
