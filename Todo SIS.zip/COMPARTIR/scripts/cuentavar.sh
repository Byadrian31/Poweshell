#!/bin/bash
#Imprimir y contar variables
c=0
for cont in "$@"; do
	echo $cont;
	echo
	let c++
done
echo "El numero de parametros es = $c "
