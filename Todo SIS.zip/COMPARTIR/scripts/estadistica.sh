#!/bin/bash
#Verificar si se pasa solo un argumento
if [ $# -ne 1 ]; then
	echo "Uso del programa ha de ser: $0 <directorio>"
	exit 1
fi

#Inicializar las variables
lectura=0; escritura=0; ejecucion=0; sin_lectura=0; sin_escritura=0; sin_ejecucion=0

# Recorrer todo tanto archivos como directorios

for i in `find $i 2>/dev/null` # no mostrar errores
do
	if [ -r $i  ]; then
		let lectura+=1
	else
		let sin_lectura+=1
	fi

        if [ -w $i  ]; then
                let escritura+=1
        else
                let sin_escritura+=1
        fi

        if [ -x $i  ]; then
                let ejecucion+=1
        else
                let sin_ejecucion+=1
        fi
done

#Mostrar contadores
echo "Nº archivos con permiso de lectura: $lectura "
echo "Nº archivos con permiso de escritura: $escritura "
echo "Nº archivos con permiso de ejecucion: $ejecucion "
echo "Nº archivos sin permiso de lectura: $sin_lectura "
echo "Nº archivos sin permiso de escritura: $sin_escritura "
echo "Nº archivos sin permiso de ejecucion: $sin_ejecucion "
