#!/bin/bash

# Verifica si se proporciona un argumento
if [ $# -ne 1 ]; then
    echo "Uso: $0 <N>"
    exit 1
fi

# Obtiene el valor de N del argumento
N=$1

# Ciclo para imprimir las filas de la pirámide
for ((i=1; i<=N; i++)); do
    # Calcula el número de espacios en blanco a imprimir en cada fila
    espacios=$((N - i))
    
    # Imprime los espacios en blanco antes de los números en la fila
    for ((j=1; j<=espacios; j++)); do
        echo -n " "
    done

    # Ciclo para imprimir los números en cada fila
    for ((k=1; k<=i; k++)); do
        # Imprime el número de la fila en cada iteración
        echo -n "$i "
    done
    
    # Salto de línea para pasar a la siguiente fila
    echo
done
