
for arg in $*
do
  echo
  echo "Contenido $arg: "
  cat $arg
  echo "<------------------------------------>"
  echo
done
