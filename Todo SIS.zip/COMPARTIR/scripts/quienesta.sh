#!/bin/bash
# Indica el número de usuarios conectados al sistema y la fecha actual

clear
test=$(who | wc -l)
echo "Usuarios: $test"
date
