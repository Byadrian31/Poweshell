#!/bin/bash
echo "La fecha de hoy es:" date
echo "Soy el usuario" whoami
echo "Me encuentro en un directorio" pwd

#Saber la ruta exacta de bash
#which bash
