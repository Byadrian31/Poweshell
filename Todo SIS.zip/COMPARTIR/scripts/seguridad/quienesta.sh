#!/bin/bash
who
