#!/bin/bash

echo "Por favor, introduce el nombre de usuario:"
read nombre

# Comprobando si el usuario está conectado
if who | grep -wq "^$nombre"; then
    echo "$nombre está conectado al sistema en estos momentos."
else
    echo "$nombre no está conectado al sistema en estos momentos."
fi
