﻿Clear-Host
function DameUser {

    $nombre = Read-Host Dame el nombre de usuario
    return $nombre

}
function DameGrupo {

    $grupo = Read-Host Dame el nombre del grupo
    return $grupo

}
function Test-passwd {

    $nombre = Read-Host Dame el nombre de usuario a poner
    $contra = Read-Host Dame la contraseña a poner
    $res = $true
    $resultado = "La contraseña es segura"

    
    if ($contra -match $nombre) {
    
        $res = $false
    
    } if ($contra -notmatch '[A-Z]') {
        $res = $false

    } if ($contra -notmatch '[a-z]') {
        $res = $false

    } if ($contra -notmatch '[0-9]') {
        $res = $false
    
    } if ($contra -notmatch '[^a-zA-Z0-9]') {
        $res = $false

    } if ($res) {
        New-LocalUser -Name $nombre -Password (ConvertTo-SecureString -AsPlainText $contra -Force) -UserMayNotChangePassword -PasswordNeverExpires 
        Add-LocalGroupMember -Group "usuarios" -Member $nombre

        $resultado = "El usuario se ha creado con éxito"
        
    } else {
        $resultado = "La contraseña no es segura"
    
    }
    return $resultado

}

do {
    Clear-Host

    Write-Host ______________________MENU_______________________
    Write-Host _________________________________________________
    Write-Host   1: Listar los usuarios.
    Write-Host   2: Crear usuario.                             
    Write-Host   3: Cambiar contraseña de un usuario.
    Write-Host   4: Desactivar usuario.
    Write-Host   5: Borrar usuario.
    Write-Host   6: Listar los grupos de usuarios del sistema.
    Write-Host   7: Listar los miembros de un grupo.
    Write-Host   8: Crear grupo.
    Write-Host   9: Borrar grupo.
    Write-Host   10: Añadir usuario a grupo.
    Write-Host   11: Borrar usuario de un grupo.
    Write-Host   12: Salir.
    Write-Host _________________________________________________

    $hacer = Read-Host Indica lo que quieres realizar

    Clear-Host

    Switch ($hacer) {
    
        '1' {
            Write-Host `n
            Get-LocalUser | Select-Object Name
            Write-Host `n
        }

        '2' {
            Write-Host `n
            $res = Test-passwd
            Write-Host $res
            Write-Host `n
        }

        '3' {
            Write-Host `n
            $nombre = DameUser
            $contra = Read-Host Indica la nueva contraseña
            Set-LocalUser -Name $nombre -Password (ConvertTo-SecureString -AsPlainText $contra -Force)
            Write-Host `n
        }

        '4' {
            Write-Host `n
            $nombre = DameUser
            Disable-LocalUser -Name $nombre
            Write-Host `n
        }
        '5' {
            Write-Host `n
            $nombre = DameUser
            Remove-LocalUser -Name $nombre
            Write-Host `n
        }
        '6' {
            Write-Host `n
            Get-LocalGroup | Select-Object Name
            Write-Host `n
        }
        '7' {
            Write-Host `n
            $grupo = DameGrupo
            Get-LocalGroupMember -Group $grupo | Select-Object Name
            Write-Host `n
        }
        '8' {
            Write-Host `n
            $grupo = DameGrupo
            New-LocalGroup -Name $grupo
            Write-Host `n
        }
        '9' {
            Write-Host `n
            $grupo = DameGrupo
            Remove-LocalGroup -Name $grupo
            Write-Host `n
        }
        '10' {
            Write-Host `n
            $nombre = DameUser
            $grupo = DameGrupo
            Add-LocalGroupMember -Group $grupo -Member $nombre
            Write-Host `n
        }
        '11' {
            Write-Host `n
            $nombre = DameUser
            $grupo = DameGrupo
            Remove-LocalGroupMember -Member $nombre -Group $grupo
            Write-Host `n
        }
        '12' { return }
        default { Write-Host Número incorrecto }

    }

    Read-Host Pulse enter para continuar
    
}while ($hacer -ne "12")