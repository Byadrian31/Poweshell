﻿# Crear un script en PowerShell copia_docs_inc.ps1 que haga una copia de seguridad
# incremental de la carpeta "Documentos" en "F:\BACKUP\". Comprimir los datos en un
# fichero con el siguiente formato 2024-02-01-docs_inc.zip

# Verificar y crear la carpeta "Documentos" si no existe
if (!(Test-Path -Path "C:\Users\Administrador\Documents")) {
    New-Item -ItemType directory -Path "C:\Users\Administrador\Documents"
}

# Verificar y crear la carpeta de respaldo si no existe
if (!(Test-Path -Path "F:\BACKUP")) {
    New-Item -ItemType directory -Path "F:\BACKUP"
}

# Obtener la fecha del día actual
$date = Get-Date -Format "yyyy-MM-dd"
$backupFileName2 = "$date-docs_inc.zip"

# Obtener la fecha del último archivo modificado
$lastFile = Get-ChildItem -Path "C:\Users\Administrador\Documents\*" -Recurse |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if ($lastFile) {
    $lastFileDate = $lastFile.LastWriteTime.Date

    # Obtener archivos y directorios modificados/creados el mismo día
    $modifiedItems = Get-ChildItem -Path "C:\Users\Administrador\Documents\*" -Recurse | Where-Object { $_.LastWriteTime.Date -eq $lastFileDate }
}

# Comprimir archivos y directorios modificados en un archivo ZIP
if ($modifiedItems.Count -gt 0) {
    Compress-Archive -Path $modifiedItems.FullName -CompressionLevel Optimal -DestinationPath "F:\BACKUP\$backupFileName2" -Force
    Write-Host "Copia de seguridad incremental creada: $backupFileName2"
} else {
    Write-Host "No hay archivos o directorios nuevos o modificados con la misma fecha que la última modificación."
}