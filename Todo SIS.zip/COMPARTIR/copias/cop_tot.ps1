﻿#Hecho por Adrian Lopez
$origen = "C:\Users\Administrador\Desktop\APUNTES"
$destino = "F:\BACKUP"

if (!(Test-Path -Path $origen )) {
    New-Item -ItemType directory -Path $origen
}

if (!(Test-Path -Path $destino )) {
    New-Item -ItemType directory -Path $destino
}

$date = Get-Date -Format "yyyy-MM-dd"
Compress-Archive -Path "$origen\*" -CompressionLevel Optimal -DestinationPath "F:\BACKUP\$date-docs_TOT.zip" -Force