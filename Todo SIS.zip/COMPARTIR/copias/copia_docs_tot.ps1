﻿#Hecho por Adrian Lopez
#Crear un script en PowerShell copia_docs_tot.ps1 que haga una copia de seguridad total de
#la carpeta "Documentos" en "F:\BACKUP\". Comprimir los datos en un fichero con el
#siguiente formato 2024-02-01-docs_tot.zip

if (!(Test-Path -Path "C:\Users\Administrador\Documents" )) {
    New-Item -ItemType directory -Path "C:\Users\Administrador\Documents"
}

if (!(Test-Path -Path "F:\BACKUP" )) {
    New-Item -ItemType directory -Path "F:\BACKUP"
}

$date = Get-Date -Format "yyyy-MM-dd"
Compress-Archive -Path "C:\Users\Administrador\Documents\*" -CompressionLevel Optimal -DestinationPath "F:\BACKUP\$date-docs_tot.zip" -Force