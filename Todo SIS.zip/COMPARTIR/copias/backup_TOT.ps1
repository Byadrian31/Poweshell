﻿#Hecho por Adrián López
$origen = "F:\BACKUP"
$destino = "C:\Users\Administrador\Desktop\APUNTES"


$nom = Read-Host "¿Que archivo quieres recuperar?(indica la extension tambien)"

if (!(Test-Path -Path $destino )) {
    New-Item -ItemType directory -Path $destino
}


Expand-Archive -Path $origen\$nom -DestinationPath $destino

Write-Host "Backup realizado correctamente"