﻿# Verificar y crear la carpeta "Documentos" si no existe
if (!(Test-Path -Path "C:\Users\Administrador\Documents")) {
    New-Item -ItemType directory -Path "C:\Users\Administrador\Documents"
}

# Verificar y crear la carpeta de respaldo si no existe
if (!(Test-Path -Path "F:\BACKUP")) {
    New-Item -ItemType directory -Path "F:\BACKUP"
}

# Obtener la fecha del día actual
$date = Get-Date -Format "yyyy-MM-dd"
$backupFileName2 = "$date-docs_dif.zip"

# Obtener la fecha del último backup
$lastFile = Get-ChildItem -Path "F:\BACKUP\*" -Filter "*tot.zip" -Recurse |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

# Obtener la fecha del último backup creado en F:\BACKUP
$lastBackupDate = Get-ChildItem -Path "F:\BACKUP\*" -Filter "*.zip" |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1 |
    ForEach-Object { $_.LastWriteTime.Date }

# Obtener archivos y directorios modificados/creados desde el último backup
$modifiedItems = Get-ChildItem -Path "C:\Users\Administrador\Documents\*" -Recurse | Where-Object { $_.LastWriteTime.Date -ge $lastBackupDate -and $_.LastWriteTime -ge $lastFile }

# Comprimir archivos y directorios modificados en un archivo ZIP
if ($modifiedItems.Count -gt 0) {
    Compress-Archive -Path $modifiedItems.FullName -CompressionLevel Optimal -DestinationPath "F:\BACKUP\$backupFileName2" -Force
    Write-Host "Copia de seguridad diferencial creada: $backupFileName2"
} else {
    Write-Host "No hay archivos o directorios nuevos o modificados desde el último backup creado en $lastBackupDate."
}
