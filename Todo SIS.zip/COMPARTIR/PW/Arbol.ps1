﻿#$x = [int] (Read-Host "Dime la altura") 
for($i=1; $i -le 5; $i++){ 
   #cambia -le $x por -le $x - $i
   for($k=1; $k -le 5 -$i; $k++ ){
      Write-Host -NoNewLine " "
   }

   for($j=1; $j -le 2 * $i - 1; $j++){ 
     Write-Host -NoNewLine "*" 
   }

   Write-Host " "
}

 Write-Host "   | |      "
 Write-Host "   | |      "
 Write-Host "Bon nadal"

