﻿#PowerShell Adrian
#Mostrar por pantalla un mensaje n veces. Numerar las líneas sacadas por pantalla de mayor
#a menor. El mensaje y el número de veces deben pedirse al usuario. Verificar que el usuario está de acuerdo con el
#mensaje y las veces que se va a mostrar

$text = Read-Host "Dime la frase que quieras"

$num = Read-Host "¿Cuantas veces quieres verlo?"
#variable contador para mostrarla despues
$cont = 1

#bucle para mostrar las veces que se indique en la variable $num
for ($i = 0; $i -lt $num;$i++){
    Write-Host $cont "." $text
    $cont++
}