﻿#PowerShell Adrian
#Generar una jugada de la bonolo de forma aleatoria, se deben seleccionar seis números diferentes
#entre el 1 y el 49
Clear-Host

Write-Host "Bonoloto"

$res = Read-Host "¿Quieres jugar? Si/No"

#Realizo un Switch para seleccionar la opcion
switch ( $res )
{
    "Si"{
    $cant = Read-Host "¿Cuantos bonolotos quieres?"
   
    for($j=0;$j -lt $cant;$j++){
    $ent = @()
    $reintegro = Get-Random -Minimum 1 -Maximum 9
        for($i=0;$i -lt $cant;$i++){
            $num = Get-Random -Minimum 1 -Maximum 49
            if($ent.Contains($num)){
                $num = Get-Random -Minimum 1 -Maximum 49
                $ent += $num
            } else {
                $ent += $num
            }
            
        }
            [array]::Sort($ent)
            Write-Host $ent + $reintegro
            
     }
    }

    "No"{
        exit
    }

}