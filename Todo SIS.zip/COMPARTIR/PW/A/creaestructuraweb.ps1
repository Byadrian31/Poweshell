﻿Clear-Host
$dir = Read-Host "Dime la ruta absoluta"
$nom = Read-Host "Dime el nombre"

New-Item -Path "$dir\$nom" -ItemType Directory
New-Item -Path "$dir\$nom\css" -ItemType Directory
New-Item -Path "$dir\$nom\imgs" -ItemType Directory

New-Item -Path "$dir\$nom\index.html" -ItemType File
New-Item -Path "$dir\$nom\css\style.css" -ItemType File

$index = @(
    "<!DOCTYPE html>"
    "<html>"
    "<head>"
    "</head>"
    "<body>"
    "</body>"
    "</html>"
)

$css = @(
   "body { }"
)

Add-Content -Path "$dir\$nom\index.html" -Value $index
Add-Content -Path "$dir\$nom\css\style.css" -Value $css