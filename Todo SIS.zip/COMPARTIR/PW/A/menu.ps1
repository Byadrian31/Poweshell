﻿#PowerShell Adrian
Clear-Host

while($true){
    Write-Host MENU
    Write-Host -------------------------------------------
    Write-Host      A.Listar los ficheros de un directorio
    Write-Host      B.Contar los ficheros que contiene un directorio
    Write-Host      C.Contar los ficheros que contiene un directorio y sus subdirectorios
    Write-Host      D.Contar los ficheros del directorio que ocupen más de 1GB
    Write-Host      E.Mostrar DIA y HORA
    Write-Host      F.Salir
    Write-Host -------------------------------------------

    $op = Read-Host "Dime la letra"
    Clear-Host

    switch ($op){
        "A"{
            $dir = Read-Host "Dime la ruta absoluta de un directorio"
            Get-ChildItem $dir
            Start-Sleep -Seconds 5
            Clear-Host
        }
        "B"{
            $dir = Read-Host "Dime la ruta absoluta de un directorio"
            (Get-ChildItem $dir).Count
            Start-Sleep -Seconds 5
            Clear-Host
        }
        "C"{
            $dir = Read-Host "Dime la ruta absoluta de un directorio"
             Get-ChildItem $dir -Recurse -Directory | Measure-Object | %{$_.Count}
             Start-Sleep -Seconds 5
             Clear-Host
        }
        "D"{
            (Get-ChildItem |Where-Object -Sum {$_.Length -gt 1GB}).Count
            Start-Sleep -Seconds 5
            Clear-Host
        }
        "E"{
            Get-Date
            Start-Sleep -Seconds 5
            Clear-Host
        }
        "F"{
             exit
        }

        default {
        Write-Host "Opcion no valida"
        }
  }
}