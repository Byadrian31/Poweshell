﻿$dividendo = Read-Host "¿dividendo?"
$divisor = Read-Host "¿divisor?"
[int]$coc = $dividendo/$divisor
$res = $dividendo%$divisor
[System.Math]::Ceiling($coc)
Write-Host "El cociente es " $coc " y el resultado es: " $res

