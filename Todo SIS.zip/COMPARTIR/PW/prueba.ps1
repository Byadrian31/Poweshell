﻿$nombre = "Hola"
$num = 4.5
[float] $temp = 4.99
[int] $num2 = 4.99
[char] $letra = 46
$fecha = [datetime]"3/22/2009"

Write-Host $nombre $num $temp $num2 $letra $fecha

Write-Host $nombre.GetType().name
Write-Host $num.GetType().name
Write-Host $temp.GetType().name
Write-Host $num2.GetType().name
Write-Host $letra.GetType().name
Write-Host $fecha.GetType().name
