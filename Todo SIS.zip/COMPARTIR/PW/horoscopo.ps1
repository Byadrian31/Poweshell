﻿Clear-Host
function Obtener-SignoHoroscopoChino {
    param([int]$anioNacimiento)

    $signos = @(
        "Mono", "Gallo", "Perro", "Cerdo", "Rata", "Buey", "Tigre", "Conejo", "Dragón", "Serpiente", "Caballo", "Cabra"
    )

    $indice = (($anioNacimiento) % 12)
    if ($indice -lt 0) {
        $indice += 12
    }
    $signo = $signos[$indice]

    return $signo
}

$anioNacimiento = Read-Host "Ingrese su año de nacimiento"

if ($anioNacimiento -match '^\d{4}$') {
    $signoHoroscopoChino = Obtener-SignoHoroscopoChino -anioNacimiento $anioNacimiento #Se verifica que la entrada sea un año válido con el patrón -match '^\d{4}$', que busca cuatro dígitos consecutivos.
    Write-Host "Su signo del horóscopo chino es: $signoHoroscopoChino"
} else {
    Write-Host "Por favor, ingrese un año válido de 4 dígitos (ej. 1980)."
}
