﻿Clear-Host
[int]$num = Read-Host "La tabla del  "

for($i = 0; $i -lt 10; $i++){
    $mult = ($i+1)
    Write-Host "$num * $mult = " ($num * $mult)
}