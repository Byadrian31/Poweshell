# Solicitar la extensión al usuario
$ext = Read-Host "Dime la extension del archivo (txt)"

# Obtener la ruta del escritorio
$ruta = [System.IO.Path]::Combine([System.Environment]::GetFolderPath("Desktop"), "listado.txt")

# Buscar archivos con la extensión especificada
$files = Get-ChildItem -Recurse -Filter "*.$ext" -File | Select-Object FullName

# Escribir la información en el archivo listado.txt
$files | ForEach-Object {
    $_.FullName | Out-File -Append -FilePath $ruta
}

Write-Host "Se ha creado el archivo 'listado.txt' en el escritorio con la lista de archivos."
