﻿Clear-Host

[int]$num = Read-Host "¿De que dimension?"

$fila = @()
for ($i = 1; $i -le $num; $i++) {
    for ($j = 1; $j -le 4; $j++) {
        Write-Host -NoNewline "$i "
    }
    Write-Host ""
}
Write-Host $fila



$fila = @()
for ($i = $num; $i -ge 1; $i--) {
    for ($j = 1; $j -le 4; $j++) {
        Write-Host -NoNewline "$i "
    }
    Write-Host ""
}
Write-Host $fila

$fila = @()
for ($i = 1; $i -le $num; $i++) {
    for ($j = 1; $j -le 4; $j++) {
        if($i % 2-eq0){
            Write-Host -NoNewline "O "
        }else{
            Write-Host -NoNewline "X "
        }
    }
    Write-Host ""
}
Write-Host $fila