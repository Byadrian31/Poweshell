﻿Clear-Host
$min = Read-Host "Dime el minimo"
$max = Read-Host "Dime el maximo"
$rand = Get-Random -Minimum $min -Maximum $max

do{
    $num = Read-Host "Prueba suerte entre $min y $max"
    if($num -lt $rand){
       Write-Host "El numero es mas grande"
    }elseif($num -gt $rand){
       Write-Host "El numero es mas pequeño"
    }else{
       Write-Host "Acertaste"
       Start-Sleep -Seconds 4
       exit
    }

}while($num -ne $rand)