﻿Clear-Host
$palabra = "Vicent"
$array = $palabra.ToCharArray()
$letra = Read-Host "Dime una letra"
[int]$cont = 0;

for($i = 0; $i -lt $array.Length; $i++){
    if($letra -eq $array[$i]){
        $pos = $i
        $cont ++
        $total = "$total, $i"
        $resp = "La letra $letra, ha salido $cont vez/veces en las posiciones $total"
    }else{
        $resp2 = "La letra no coincide"
    }

}

if($cont -eq 0){
    Write-Host $resp2
}else{
    Write-Host $resp
}