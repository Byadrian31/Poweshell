﻿$n1 = 1
$n2 = 2
$suma = $n1+$n2
Write-Host $suma

$nombre = "aS"
Write-Host $nombre*5