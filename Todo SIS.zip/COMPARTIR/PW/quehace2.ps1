﻿Clear-Host
#Buscar archivos qe coincidan con la ext ·e para la ruta $d incluyendo subcarpetas de manera recursiva
#Crear archivo zip que contiene los archivos especificados en las variables anteriores
$e = Read-Host "Dime la extension"
$d = Read-Host "Dime el directorio"
$n = Read-Host "Ruta donde alojarlo"
#Busqueda de ficheros por ext
$a = Get-ChildItem -Path $env:USERPROFILE\$d -Recurse -Filter "*$e" -File
#Compresion
Compress-Archive -Path $a.FullName -DestinationPath $env:USERPROFILE\$n