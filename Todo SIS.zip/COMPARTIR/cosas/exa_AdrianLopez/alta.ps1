﻿#Hecho por Adrian Lopez
# Ruta al archivo CSV
$rutaArchivo = Read-Host "Dime toda la ruta donde esta el archivo(el archivo lo añado yo al final de la ruta)"
$arch = "alta_usu.csv"
$rutacom = "$rutaArchivo\$arch"

# Verificar si el archivo CSV existe
if (Test-Path $rutacom) {
    # Leer los usuarios desde el archivo CSV
    $usuarios = Import-Csv $rutacom

    # Recorrer la lista de usuarios
    foreach ($usuario in $usuarios) {
        $nombreUsuario = $usuario.Nombre
        $departamento = $usuario.Grupo

        # Verificar si el grupo ya existe
        if (-not (Get-LocalGroup -Name $departamento -ErrorAction SilentlyContinue)) {
            # Crear el grupo si no existe
            New-LocalGroup -Name $departamento
           
        }

        # Verificar si el usuario ya existe
        if (-not (Get-LocalUser -Name $nombreUsuario -ErrorAction SilentlyContinue)) {
            # Crear el usuario si no existe, la contraseña se crea en base del nombre añadiendole 123 al final
            $pass = $nombreUsuario + "123"
            New-LocalUser -Name $nombreusuario -Password (ConvertTo-SecureString -AsPlainText $pass -Force)
            Add-LocalGroupMember -Name $departamento -Member $nombreUsuario
            Write-Host "Usuario '$nombreUsuario' creado en el grupo '$departamento'" -ForegroundColor Green
        } else {
            #Si el usuario ya existe no se creará
            Write-Host "Usuario '$nombreUsuario' ya existe. No se ha creado." -ForegroundColor Yellow
        }
    }
} else {
# En caso de no existir el archivo csv o no encontrarlo se muestra el siguiente mensaje de error
    Write-Host "El archivo CSV '$rutacom' no existe." -ForegroundColor Red
}
