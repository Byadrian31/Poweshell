﻿#Hecho por Adrian Lopez
Clear-Host
# Se definen las variables correspondientes
$rutaDirectorio = "C:\DAW-SI"
$gral = "alumnes"
$usuario = "vicent"

# Se comprueba si el directorio existe, en caso de que no exista se crea
if (-not (Test-Path $rutaDirectorio)) {
    New-Item -Path $rutaDirectorio -ItemType Directory
}

# Se comprueba si el grupo y el usuario existe(se intuye que si, pero se comprueba por si acaso), en caso de no existir se crea
if (-not (Get-LocalGroup -Name $gral -ErrorAction SilentlyContinue)) {
    New-LocalGroup -Name $gral
}

if (-not (Get-LocalUser -Name $usuario -ErrorAction SilentlyContinue)) {
    $pass = "TuPassword123!"
    New-LocalUser -Name $usuario -Password (ConvertTo-SecureString -AsPlainText $pass -Force)
    Add-LocalGroupMember -Name Usuarios -Member $usuario
}


# Asignar permisos NTFS
$acl = Get-Acl -Path $rutaDirectorio

# Permisos para vicent (lectura)
$rulealumnes = New-Object System.Security.AccessControl.FileSystemAccessRule($gral, "Read", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($rulealumnes)

# Permisos para vicent (control total)
$rulevicent = New-Object System.Security.AccessControl.FileSystemAccessRule($usuario, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($rulevicent)

# Aplicar cambios en los permisos NTFS
Set-Acl -Path $rutaDirectorio -AclObject $acl

Write-Host "Directorio creado, grupo alumnes creado y usuario creado (si no existían) y permisos NTFS asignados correctamente." -ForegroundColor Green