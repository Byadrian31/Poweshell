﻿# Solicitar al usuario el nombre del servicio que desea detener
$serviceName = Read-Host "Ingrese el nombre del servicio que desea detener"

# Verificar si el servicio está en ejecución
    # Detener el servicio
    Stop-Service -Name $serviceName -Force
    Write-Host "El servicio '$serviceName' se detuvo correctamente." -ForegroundColor Green

