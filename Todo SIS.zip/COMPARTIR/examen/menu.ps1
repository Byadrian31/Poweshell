function CrearFichero {
    $nombre = Read-Host "Ingrese el nombre del archivo"
    $ubicacion = Read-Host "Ingrese la ubicación del archivo"

    # Solicitar contenido en múltiples líneas
    $contenido = ""
    do {
        $linea = Read-Host "Ingrese una línea de contenido (deje en blanco para finalizar)"
        if ($linea -ne "") {
            $contenido += $linea + "`r`n"  # Agregar línea al contenido con retorno de carro y salto de línea
        }
    } while ($linea -ne "")

    $rutaCompleta = Join-Path $ubicacion $nombre
    Set-Content -Path $rutaCompleta -Value $contenido
    Write-Host "Archivo creado exitosamente en: $rutaCompleta"
}

function CopiarFichero {
    $nombre = Read-Host "Ingrese el nombre del archivo"
    $ubicacionOriginal = Read-Host "Ingrese la ubicación original del archivo"
    $ubicacionFinal = Read-Host "Ingrese la ubicación final del archivo"

    $rutaOriginal = Join-Path $ubicacionOriginal $nombre
    $rutaFinal = Join-Path $ubicacionFinal $nombre
    Copy-Item -Path $rutaOriginal -Destination $rutaFinal
    Write-Host "Archivo copiado exitosamente a: $rutaFinal"
}

function BorrarFichero {
    $nombre = Read-Host "Ingrese el nombre del archivo"
    $ubicacion = Read-Host "Ingrese la ubicación del archivo"

    $rutaCompleta = Join-Path $ubicacion $nombre
    Remove-Item -Path $rutaCompleta -Force
    Write-Host "Archivo borrado exitosamente: $rutaCompleta"
}

function MoverFichero {
    $nombre = Read-Host "Ingrese el nombre del archivo"
    $ubicacionOriginal = Read-Host "Ingrese la ubicación original del archivo"
    $ubicacionFinal = Read-Host "Ingrese la ubicación final del archivo"

    $rutaOriginal = Join-Path $ubicacionOriginal $nombre
    $rutaFinal = Join-Path $ubicacionFinal $nombre
    Move-Item -Path $rutaOriginal -Destination $rutaFinal
    Write-Host "Archivo movido exitosamente a: $rutaFinal"
}

do {
    Write-Host "Menú interactivo:"
    Write-Host "a. Crear fichero"
    Write-Host "b. Copiar fichero"
    Write-Host "c. Borrar fichero"
    Write-Host "d. Mover fichero"
    Write-Host "e. Salir"

    $opcion = Read-Host "Seleccione una opción"

    switch ($opcion) {
        'a' { CrearFichero }
        'b' { CopiarFichero }
        'c' { BorrarFichero }
        'd' { MoverFichero }
        'e' { break }
        default { Write-Host "Opción no válida. Por favor, seleccione de nuevo." }
    }
} while ($true)
