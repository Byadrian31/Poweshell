function Generar-Bonoloto {
    param (
        [int]$cantidad
    )

    for ($i = 1; $i -le $cantidad; $i++) {
        $bonoloto = Get-Random -Count 6 -InputObject (1..49) | Sort-Object
        $reintegro = Get-Random -Minimum 0 -Maximum 10

        Write-Output "Bonoloto #$i $($bonoloto -join ', ') - Reintegro: $reintegro"
    }
}

# Solicitar la cantidad de bonolotos a generar
$numeroBonolotos = Read-Host "Ingrese la cantidad de Bonolotos que desea generar"

# Validar que la entrada sea un número entero positivo
if ($numeroBonolotos -match '^\d+$') {
    Generar-Bonoloto -cantidad $numeroBonolotos
} else {
    Write-Host "Por favor, ingrese un número entero positivo."
}
