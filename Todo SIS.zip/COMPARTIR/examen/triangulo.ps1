# Solicitar al usuario la altura del triángulo
$altura = Read-Host "Ingrese la altura del triángulo"

# Convertir la entrada del usuario a un número entero
$altura = [int]$altura

# Bucle para imprimir el triángulo
for ($i = $altura; $i -ge 1; $i--) {
    # Bucle interno para imprimir cada fila del triángulo
    for ($j = $altura; $j -ge $i; $j--) {
        Write-Host -NoNewline "$i "
    }
    Write-Host ""  # Nueva línea después de imprimir cada fila
}
