$extension = Read-Host "Dime la extensión"
$drives = Get-PSDrive -PSProvider 'FileSystem'
foreach ($drive in $drives) {
    $files = Get-ChildItem -Path $drive.Root -Filter "*$extension" -Recurse
    
        foreach ($file in $files) {
            $info = "N: $($file.Name), U: $($file.Directory), T: $($file.Length) bytes, F: $($file.LastWriteTime)"
         $info | Out-File -FilePath listado.txt -Append #Append añade al final del archivo
           }
 }