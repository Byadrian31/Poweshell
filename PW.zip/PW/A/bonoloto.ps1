﻿#PowerShell Adrian
#Generar una jugada de la bonolo de forma aleatoria, se deben seleccionar seis números diferentes
#entre el 1 y el 49

Write-Host "Bonoloto"

$res = Read-Host "¿Quieres jugar? Si/No"
#Realizo un Switch para seleccionar la opcion
switch ( $res )
{
    "Si"{
    $ent = @()
        for($i=0;$i -lt 6;$i++){
            $num = Get-Random -Minimum 1 -Maximum 49
            if($ent.Contains($num)){
                $num = Get-Random -Minimum 1 -Maximum 49
                $ent += $num
            } else {
                $ent += $num
            }
        }

            Write-Host $ent   
    }

    "No"{
        exit
    }

}