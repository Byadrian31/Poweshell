﻿#Adrian Lopez a dia de hoy
Clear-Host
$dir = Read-Host "Dime la ruta absoluta"
$ext = Read-Host "Dime la extension (.txt)"


if(Test-Path -Path "$dir\*$ext"){

    Move-Item -Path "$dir\*$ext" -Destination "C:\Users\$env:USERNAME\Downloads"

    Write-Host "Hemos desplazado tus archivos a C:\Users\$env:USERNAME\Downloads"

    $op = Read-Host "¿Quieres borrar los datos? Si/No"

    if ($op -eq "Si"){
        Remove-Item -Path "C:\Users\$env:USERNAME\Downloads\*$ext"
    }elseif($op -eq "No"){
        Write-Host "Dejamos los archivos en la carpeta descargas"
    }else{
        Write-Host "Opcion no valida"
    }
}else{
    Write-Host "En $dir no hay ningun archivo con la extension $ext"
}