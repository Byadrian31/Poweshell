﻿Clear-Host
$extension = Read-Host "Dime la extension" #funciona
$drives = Get-PSDrive -PSProvider 'FileSystem' #Get-PSDrive devuelve todas las unidades y el resto devuelve el espacio usado donde el provedor sea FileSystem
foreach ($drive in $drives) {
    $files = Get-ChildItem -Path $drive.Root -Filter "*$extension" -Recurse
    
    foreach ($file in $files) {
        #$info = "N: $($file.Name), U: $($file.Directory), T: $($file.Length) bytes, F: $($file.LastWriteTime)"
        $info = "N: $($file.Name), U: $($file.Directory)"
        $info | Out-File -FilePath $env:UserProfile\Desktop\listado.txt -Append
    }
}
