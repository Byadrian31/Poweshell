﻿Write-Host "Hola Mundo"

$nombre = "Hola Adrian"
Write-Host $nombre
New-Variable -Name nombre2 -Value "Lopez"
Write-Host $nombre2
New-Variable -Name nombre3 -Value "Pascual" -Option ReadOnly
Write-Host $nombre3
$nombre_completo = Read-Host "¿Como te llamas?"
Write-Host "Hola $nombre_completo"