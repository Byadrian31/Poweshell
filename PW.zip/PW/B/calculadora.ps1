﻿#PowerShell Adrian
Clear-Host

while($true){
    Write-Host MENU
    Write-Host -------------------------------------------
    Write-Host      A.Sumar
    Write-Host      B.Restar
    Write-Host      C.Multiplicar
    Write-Host      D.Dividir
    Write-Host      E.Potencia
    Write-Host      F.Salir
    Write-Host -------------------------------------------

    $op = Read-Host "¿Qué operación vas a realizar?"
    if($op -eq "F"){
        exit
    }

    [int]$num1 = Read-Host "Dime el primer numero: "
    [int]$num2 = Read-Host "Dime el segundo numero: "
    
    Clear-Host

    switch ($op){
        "A"{
            $sum = ($num1 + $num2)
            Write-Host "El resultado es: "  $sum
            Start-Sleep -Seconds 5
            Clear-Host
        }
        "B"{
            $res = ($num1 - $num2)
            Write-Host "El resultado es: "  $res
            Start-Sleep -Seconds 5
            Clear-Host
        }
        "C"{
             $mult = ($num1 * $num2)
             Write-Host "El resultado es: "  $mult 
             Start-Sleep -Seconds 5
             Clear-Host
        }
        "D"{
            if($num1 -ge $num2){
            $div = ($num1 / $num2)
            Write-Host "El resultado es: "  $div
            Start-Sleep -Seconds 5
            Clear-Host
            }else{
                Write-Host "El segundo numero tiene que ser mayor que el primero"
                Start-Sleep -Seconds 5
                Clear-Host
            }
        }
        "E"{
            "El resultado es: " + [Math]::Pow($num1,$num2)
            Start-Sleep -Seconds 5
            Clear-Host
        }
        

        default {
        Write-Host "Opcion no valida"
        Clear-Host
        }
  }
}