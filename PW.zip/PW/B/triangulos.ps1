﻿Clear-Host
[int]$tamaño = Read-Host "Dime el tamaño"
$salida = ""
for($i = 0; $i -lt $tamaño; $i++){
    $salida+= "*"
    Write-Host $salida
}

Write-Host "---------------"

[int]$tamaño2 = Read-Host "Dime el tamaño"
$salida2 = ""
for($i = $tamaño2; $i -ge 1; $i--){
    $espacio= " " * ($tamaño2 - $i)
    $salida2= "*" * $i + $espacio
    Write-Host $salida2
}