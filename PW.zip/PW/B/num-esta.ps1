﻿Clear-Host
$min = Read-Host "Dime el minimo"
$max = Read-Host "Dime el maximo"
$cont = Read-Host "Cuantos numeros quieres que hayan"

$cnum = @()

for($i=0; $i -lt $cont; $i++){
    $rand = Get-Random -Minimum $min -Maximum $max
    $cnum += $rand
}

$num = Read-Host "¿Que numero quieres comprobar?"
for([int]$i=0 ;$i -lt $cont; $i++){
    if($num -ne $cnum[$i]){
        $resp = "El numero no esta"
    }else{
      $pos = $i
      $resp = "El numero se ha encontrado en la posicion " + $pos
      $i = $cont
    }
}

Write-Host $resp