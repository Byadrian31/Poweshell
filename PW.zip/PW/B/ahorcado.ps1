﻿Clear-Host
$palabra = "powershell"
$array = $palabra.ToCharArray()
$al = @()
for ($i = 0; $i -lt $array.Length; $i++) {
    $al += "_"
}

Write-Host "Bienvenido al ahorcado, el tema es programacion"

[int]$cont = 0
[int]$intentos = 6
$find = $false

do{
    $intentosRestantes = $intentos
    Write-Host "Tienes $intentosRestantes intentos"
    Write-Host $al
    $letra = Read-Host "Dime una letra: "
    $find = $false

     if($al.Contains($letra)){
            Write-Host "Ey fiera que esa ya la has usado"
            }

    for($i = 0; $i -lt $array.Length; $i++){
        if($letra -eq $array[$i]){
            $al[$i] = $letra
            $find = $true
        }
    }

    if (-not $find) {
        Write-Host "La letra '$letra' no coincide"
        $intentos--
    }

    $adivinadoCompleto = -not $al.Contains("_")

    if ($adivinadoCompleto) {
        Write-Host "Felicidades, has ganado"
        Write-Host $al
        exit
    }
   
}while($intentos -gt 0)

if ($intentos -eq 0){
    Write-Host "Te has quedado sin intentos, perdiste, la palabra era $palabra"
}