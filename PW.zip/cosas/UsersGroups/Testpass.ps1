﻿Clear-Host

function Test-passwd {

    $nombre = Read-Host Dame el nombre de usuario a poner
    $contra = Read-Host Dame la contraseña a poner
    $res = $true
    $resultado = "La contraseña es segura"

    
    if ($contra -match $nombre) {
    
        $res = $false
    
    } if ($contra -notmatch '[A-Z]') {
        $res = $false

    } if ($contra -notmatch '[a-z]') {
        $res = $false

    } if ($contra -notmatch '[0-9]') {
        $res = $false
    
    } if ($contra -notmatch '[^a-zA-Z0-9]') {
        $res = $false

    } if ($res) {
        $resultado = $contra
        
    } else {
        $resultado = "La contraseña no es segura"
    
    }

    return $resultado

}

Test-passwd