﻿# Crear o verificar existencia de grupos
$null = New-LocalGroup -Name "IES" -ErrorAction SilentlyContinue
$null = New-LocalGroup -Name "DAW" -ErrorAction SilentlyContinue
$null = New-LocalGroup -Name "DAM" -ErrorAction SilentlyContinue

# Crear o verificar existencia de usuarios
$null = New-LocalUser -Name "Jaime" -ErrorAction SilentlyContinue
$null = New-LocalUser -Name "Belén" -ErrorAction SilentlyContinue
$null = New-LocalUser -Name "Marta" -ErrorAction SilentlyContinue
$null = New-LocalUser -Name "Luis" -ErrorAction SilentlyContinue
$null = New-LocalUser -Name "Carlos" -ErrorAction SilentlyContinue
$null = New-LocalUser -Name "Juan" -ErrorAction SilentlyContinue

# Agregar usuarios a grupos
Add-LocalGroupMember -Group "IES" -Member "Jaime", "Belén", "Marta", "Luis", "Carlos", "Juan" -ErrorAction SilentlyContinue
Add-LocalGroupMember -Group "Usuarios" -Member "Jaime", "Belén", "Marta", "Luis", "Carlos", "Juan" -ErrorAction SilentlyContinue

Add-LocalGroupMember -Group "DAW" -Member "Luis", "Carlos" -ErrorAction SilentlyContinue
Add-LocalGroupMember -Group "DAM" -Member "Belén", "Marta" -ErrorAction SilentlyContinue



# Crear o verificar existencia de directorios
$seniaPath = "C:\Users\AdrianVB\Desktop\SENIA"
$apuntesPath = "C:\Users\AdrianVB\Desktop\SENIA\APUNTES"
$dawPath = "C:\Users\AdrianVB\Desktop\SENIA\APUNTES\DAW"
$damPath = "C:\Users\AdrianVB\Desktop\SENIA\APUNTES\DAM"

foreach ($path in $seniaPath, $apuntesPath, $dawPath, $damPath) {
    if (-not (Test-Path $path)) {
        New-Item -Path $path -ItemType Directory
    }
}

# Establecer permisos
# C:\SENIA
$aclSenia = Get-Acl $seniaPath
$iesGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("IES", "Read", "Allow")
$aclSenia.SetAccessRule($iesGroup)
Set-Acl $seniaPath $aclSenia

# C:\SENIA\APUNTES
$aclApuntes = Get-Acl $apuntesPath
$juanProfesor = New-Object System.Security.AccessControl.FileSystemAccessRule("Juan", "FullControl", "Allow")
$aclApuntes.SetAccessRule($juanProfesor)
Set-Acl $apuntesPath $aclApuntes

# C:\SENIA\APUNTES\DAW
$aclDAW = Get-Acl $dawPath
$dawGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("DAW", "Read", "Allow")
$aclDAW.SetAccessRule($dawGroup)


$dawGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("DAW", "Write", "Allow")


$dawGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("DAW", "Execute", "Allow")
$aclDAW.SetAccessRule($dawGroup)
Set-Acl $dawPath $aclDAW


# C:\SENIA\APUNTES\DAM
$aclDAM = Get-Acl $damPath
$damGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("DAM", "Read", "Allow")
$aclDAM.SetAccessRule($damGroup)


$damGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("DAM", "Write", "Allow")
$aclDAM.SetAccessRule($damGroup)


$damGroup = New-Object System.Security.AccessControl.FileSystemAccessRule("DAM", "Execute", "Allow")
$aclDAM.SetAccessRule($damGroup)
Set-Acl $damPath $aclDAM
