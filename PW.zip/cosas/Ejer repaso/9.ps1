﻿# Definir variables
$rutaDirectorio = "C:\DAW-SI"
$grupoProfesores = "profesores"
$grupoAlumnos = "alumnos"

# Crear directorio si no existe
if (-not (Test-Path $rutaDirectorio)) {
    New-Item -Path $rutaDirectorio -ItemType Directory
}

# Crear grupos si no existen
if (-not (Get-LocalGroup -Name $grupoProfesores -ErrorAction SilentlyContinue)) {
    New-LocalGroup -Name $grupoProfesores
}

if (-not (Get-LocalGroup -Name $grupoAlumnos -ErrorAction SilentlyContinue)) {
    New-LocalGroup -Name $grupoAlumnos
}

# Asignar permisos NTFS
$acl = Get-Acl -Path $rutaDirectorio

# Permisos para profesores (escritura)
$ruleProfesores = New-Object System.Security.AccessControl.FileSystemAccessRule($grupoProfesores, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($ruleProfesores)

# Permisos para alumnos (lectura)
$ruleAlumnos = New-Object System.Security.AccessControl.FileSystemAccessRule($grupoAlumnos, "Read", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($ruleAlumnos)

# Aplicar cambios en los permisos NTFS
Set-Acl -Path $rutaDirectorio -AclObject $acl

Write-Host "Directorio creado, grupos creados (si no existían) y permisos NTFS asignados correctamente." -ForegroundColor Green