﻿# Ruta al archivo CSV
$rutaArchivo = "C:\Users\$env:USERNAME\Desktop\Ejer repaso\alta_usu.csv"

# Verificar si el archivo CSV existe
if (Test-Path $rutaArchivo) {
    # Leer los usuarios desde el archivo CSV
    $usuarios = Import-Csv $rutaArchivo

    # Recorrer la lista de usuarios
    foreach ($usuario in $usuarios) {
        $nombreUsuario = $usuario.Nombre
        $departamento = $usuario.Departamento

        # Verificar si el grupo ya existe
        if (-not (Get-LocalGroup -Name $departamento -ErrorAction SilentlyContinue)) {
            # Crear el grupo si no existe
            New-LocalGroup -Name $departamento
           
        }

        # Verificar si el usuario ya existe
        if (-not (Get-LocalUser -Name $nombreUsuario -ErrorAction SilentlyContinue)) {
            # Crear el usuario si no existe
            $pass = ConvertTo-SecureString "TuPassword123!" -AsPlainText -Force
            New-LocalUser -Name $nombreUsuario -Password $pass
            Add-LocalGroupMember -Name $departamento -Member $nombreUsuario
            Write-Host "Usuario '$nombreUsuario' creado en el grupo '$departamento'" -ForegroundColor Green
        } else {
            Write-Host "Usuario '$nombreUsuario' ya existe. No se ha creado." -ForegroundColor Yellow
        }
    }
} else {
    Write-Host "El archivo CSV '$rutaArchivo' no existe." -ForegroundColor Red
}
