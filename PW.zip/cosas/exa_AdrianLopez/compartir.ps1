﻿#Hecho por Adrian Lopez
Clear-Host
# Las siguientes variables recopilan todos los datos que he creido necesarios para poder compartir un recurso
$recursoCompartido = Read-Host "Dime el nombre de la carpeta que quieres compartir"
$rutaBase = "C:"
$rutaCarpeta = Join-Path -Path $rutaBase -ChildPath $recursoCompartido
$usu1 = Read-Host "Dime el nombre de un usuario: "
$usu2 = Read-Host "Dime el nombre de otro usuario: "
$contrasenaComun = "Contrasena1234!"  # Contraseña común para ambos usuarios
$perm1 = Read-Host "Dime el permiso para el usuario(Read,Write,FullControl):  "
$perm2 = Read-Host "Dime el permiso para el usuario(Read,Write,FullControl):  "
#Muestro la contraseña, sabiendo que no es seguro pero cuando ellos inicien sesion podran cambiarla
Write-Host "La contrasena de ambos es: " $contrasenaComun 

# Crear carpeta si no existe
if (-not (Test-Path $rutaCarpeta)) {
    New-Item -Path $rutaCarpeta -ItemType Directory
}

# Crear usuarios si no existen
if (-not (Get-LocalUser -Name $usu1 -ErrorAction SilentlyContinue)) {
    New-LocalUser -Name $usu1 -Password (ConvertTo-SecureString $contrasenaComun -AsPlainText -Force)
}

if (-not (Get-LocalUser -Name $usu2 -ErrorAction SilentlyContinue)) {
    New-LocalUser -Name $usu2 -Password (ConvertTo-SecureString $contrasenaComun -AsPlainText -Force) -Description "Usuario con permisos de lectura"
}

# Crear recurso compartido y añadiendo los permisos de los usuarios en base a los permisos recogidos de las variables

   switch($perm1){
   "Read" {
   New-SmbShare -Name $recursoCompartido -Path $rutaCarpeta 
   Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu1 -AccessRight Read
    if($perm2 = "Read"){
        
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Read
    }

    elseif($perm2 = "Write"){
        
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Change
    }


    elseif($perm2 = "FullControl"){
        
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Full
    }

    Write-Host "Usuarios y recurso compartido creados correctamente." -ForegroundColor Green

   }

   "Write"{
        New-SmbShare -Name $recursoCompartido -Path $rutaCarpeta 
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu1 -AccessRight Change
   if($perm2 = "Read"){
 
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Read
    }

    elseif($perm2 = "Write"){
       
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Change
    }


    elseif($perm2 = "FullControl"){
       
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Full
    }

    Write-Host "Usuarios y recurso compartido creados correctamente." -ForegroundColor Green
   }

   "FullControl"{
     New-SmbShare -Name $recursoCompartido -Path $rutaCarpeta 
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu1 -AccessRight Full
         if($perm2 = "Read"){
       
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Read
    }

    elseif($perm2 = "Write"){
        
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Change
    }

    elseif($perm2 = "FullControl"){
       
        Grant-SmbShareAccess -Name $recursoCompartido -AccountName $usu2 -AccessRight Full
    }

    Write-Host "Usuarios y recurso compartido creados correctamente." -ForegroundColor Green
   }

   default{
    Write-Host "El permiso indicado no es valido"

   }
}