﻿#Hecho por Adrián López
#Antes de empezar con el script cabe mencionar que el usuario no debe crearse y de manera opcional comprobarse puesto que la tarea programada se ejecuta sobre el propio usuario
Clear-Host

#Almacenamos en tres variables la ruta del escritorio, la extensión requerida y la carpeta destino

$dir = "C:\Users\$env:USERNAME\Desktop"
$ext = .pdf

$folderPath = "C:\DAW-SI"

#Se comprueba si la carpeta destino existe, si no existe se crea
if(!(Test-Path -Path $folderPath ))
{
    New-Item -ItemType directory -Path $folderPath
}


#Se comprueba si hay archivos con esa extension en el directorio indicado con anterioridad(se intuye que no hace falta comprobar si la carpeta "Escritorio existe")
if(Test-Path -Path "$dir\*$ext"){

#Se desplazan los archivos correspondientes al destino
        Move-Item -Path "$dir\*$ext" -Destination "C:\DAW-SI"

        Write-Host "Hemos desplazado tus archivos a C:\DAW-SI"

    
    }else{
#En caso de que no hayan archivos .pdf se indicara el siguiente mensaje
    Write-Host "En $dir no hay ningun archivo con la extension $ext"
    }
}