﻿#Hecho por Adrian Lopez
param (
    [string]$nombreMenu
)



#Uso de bucle do while para mantener el menu activo hasta que queramos salir

do {
    Clear-Host
    Write-Host "A. Lista procesos"
    Write-Host "B. Inicia proceso"
    Write-Host "C. Para proceso"
    Write-Host "D. Salir"
    
    #Creacion de variable para pedir al usuario una opcion
    $opcion = Read-Host "Selecciona una opción"

    #Bucle switch para dirigir la variable anterior a la ejecucion correspondiente
    switch ($opcion) {
        "A" {
            # Listar los procesos
            Get-Process
            Read-Host "Presiona Enter para continuar..."
        }
        "B" {
            # Iniciar el proceso indicado
            $starts = Read-Host "Dime la ruta del proceso a iniciar"
            Start-Process -FilePath $starts
            Write-Host "El servicio '$startt' se inicio correctamente." -ForegroundColor Green
            Read-Host "Presiona Enter para continuar..."
        }
        "C" {
            # Detener el proceso indicado
            $proc = Read-Host "Dime el nombre del proceso a parar"
            Stop-Process -Name $proc -Force
            Write-Host "El proceso '$proc' se detuvo correctamente." -ForegroundColor Green
            Read-Host "Presiona Enter para continuar..."
            
        }
        "D" {
            # Salir del menú
            Write-Host "Saliendo del menú..."
            exit
        }
        default {
        #Opción por defecto por si no se introduce una opción valida
            Write-Host "Opción no válida. Inténtalo de nuevo."
            Read-Host "Presiona Enter para continuar..."
        }
    }
} while ($true)